This was made by RobinHood projects. It is an open source program available to everyone:

Discord server: https://discord.gg/3hn7aqR3Za